This module was written to provide common legal page needed in any website.
This legal page must be edited using the website builder.
