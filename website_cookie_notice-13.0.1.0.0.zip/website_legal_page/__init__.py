# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from . import controllers
from .hooks import post_init_hook, _merge_views
