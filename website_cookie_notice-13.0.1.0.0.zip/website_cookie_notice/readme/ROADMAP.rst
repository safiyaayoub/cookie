* Before version 8.0.2.0.0 of this module, users had the ability to configure
  the message functionality and appearance from the main company form.

  Now, the message is generated in a view. This means that after upgrading to
  >= 8.0.2.0.0 you will lose your previous customized messages. If you want to
  customize it, please follow steps in the configuration section.

Future plans :

* Add cookie categories and let the user decide to accept/decline those cookies
* Let the website designer define which cookies from which origins belong to which category
* Disable non-required cookies by default and only enable if the user has accepted
* Adapt cookie notice message accordingly
* Set cookies for acceptance of each category
