To change the cookie message:

* Go to *Settings > Technical > User Interface > Views*.
* Search for the view called *cookie_message*.
* Change as you wish. Remember that you will probably lose translations then.

* Can also change the message directly from the website using the 'Website Builder'
* Be aware that these changes are by website.


If you are developing a theme for Odoo, remember that this message has the
``cc-cookies`` class. You can style it at will too.

To change the link to the legal page:
* Overwrite the *<a></a>* in the cookie_message_container view
